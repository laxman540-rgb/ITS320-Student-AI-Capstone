AI-Based Student Productivity and Performance Prediction System
Final Random Forest + Futuristic UI + BIT Subject Upgrade

HOW TO RUN
1. Open terminal in the app folder.
2. Install requirements:
   pip install -r requirements.txt
3. Run:
   python app.py
4. Open:
   http://127.0.0.1:5000

DEMO LOGINS
Admin: admin / 123
Teacher: teacher / 123
Students: laxman / 123, nabin / 123, nishan / 123, aakriti / 123, maya / 123, suman / 123

BEST PRESENTATION FLOW
1. Open /demo first to show both student and teacher sides together.
2. Open /model to explain Random Forest evidence.
3. Login as admin to show institutional management.
4. Login as teacher to show intervention dashboard.
5. Login as student to show subject choices, grade results, AI prediction and recommendations.

WHAT IS NEW
- Modern futuristic AI interface.
- BIT Year 1, Year 2 and Year 3 student setup.
- Student subject selection from 1 to 4 units.
- Three trimester date periods.
- Subject result release dates.
- Assessment marks, final marks and grades.
- Role-specific admin, teacher and student professional views.
- Combined demo dashboard for supervisor presentation.

IMPORTANT NOTE
This is a capstone prototype. It uses synthetic training data for Random Forest model demonstration. In a production university system, real de-identified student data, secure authentication and institutional approval would be required.
