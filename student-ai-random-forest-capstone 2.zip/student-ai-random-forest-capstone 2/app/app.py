from datetime import datetime, date
from io import StringIO
import csv
import random

from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, mean_absolute_error

from flask import Flask, Response, redirect, render_template, request, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///student_ai.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)

TRIMESTERS = {
    "Trimester 1 2026": {"start": "2026-02-16", "census": "2026-03-06", "assessment_due": "2026-05-22", "results": "2026-06-12"},
    "Trimester 2 2026": {"start": "2026-06-22", "census": "2026-07-10", "assessment_due": "2026-09-25", "results": "2026-10-16"},
    "Trimester 3 2026": {"start": "2026-10-26", "census": "2026-11-13", "assessment_due": "2027-02-05", "results": "2027-02-26"},
}

BIT_UNITS = {
    1: [
        ("ITS101", "Programming Fundamentals"),
        ("ITS102", "Database Fundamentals"),
        ("ITS103", "Computer Systems"),
        ("ITS104", "Web Development Basics"),
        ("BUS101", "Academic and Professional Skills"),
    ],
    2: [
        ("ITS201", "Systems Analysis and Design"),
        ("ITS202", "IT Project and Quality Management"),
        ("ITS203", "Networking and Security"),
        ("ITS204", "Data Analytics"),
        ("ITS205", "Software Engineering"),
    ],
    3: [
        ("ITS301", "Advanced Database Systems"),
        ("ITS302", "Cloud and Enterprise Systems"),
        ("ITS303", "AI and Machine Learning"),
        ("ITS320", "Capstone Experience"),
        ("ITS321", "Professional IT Practice"),
    ],
}

GRADE_BANDS = [(85, "HD"), (75, "D"), (65, "C"), (50, "P"), (0, "F")]

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(50), nullable=False, default="123")
    role = db.Column(db.String(20), nullable=False)
    full_name = db.Column(db.String(100), nullable=False)

class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    name = db.Column(db.String(100), nullable=False)
    student_id = db.Column(db.String(30), nullable=False)
    course = db.Column(db.String(100), nullable=False, default="Bachelor of Information Technology")
    year_level = db.Column(db.Integer, default=1)
    trimester = db.Column(db.String(40), default="Trimester 1 2026")
    teacher_name = db.Column(db.String(100), nullable=False, default="Academic Supervisor")

    attendance = db.Column(db.Integer, default=70)
    study_hours = db.Column(db.Integer, default=2)
    assignments = db.Column(db.Integer, default=3)
    quiz = db.Column(db.Integer, default=60)
    lms_logins = db.Column(db.Integer, default=5)
    engagement = db.Column(db.Integer, default=60)
    missed_tasks = db.Column(db.Integer, default=1)

    productivity = db.Column(db.Integer, default=0)
    risk = db.Column(db.String(20), default="Medium")
    expected_grade = db.Column(db.String(20), default="C")
    pass_probability = db.Column(db.Integer, default=70)
    notification = db.Column(db.Text, default="")
    recommendation = db.Column(db.Text, default="")
    reason = db.Column(db.Text, default="")
    teacher_action = db.Column(db.Text, default="")

    streak = db.Column(db.Integer, default=3)
    daily_goal_done = db.Column(db.Integer, default=2)
    daily_goal_total = db.Column(db.Integer, default=4)
    weekly_goal_done = db.Column(db.Integer, default=8)
    weekly_goal_total = db.Column(db.Integer, default=12)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class SubjectEnrollment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_username = db.Column(db.String(50), db.ForeignKey("student.username"), nullable=False)
    unit_code = db.Column(db.String(20), nullable=False)
    unit_name = db.Column(db.String(120), nullable=False)
    year_level = db.Column(db.Integer, default=1)
    trimester = db.Column(db.String(40), default="Trimester 1 2026")
    assessment_due = db.Column(db.String(20), default="2026-05-22")
    result_release = db.Column(db.String(20), default="2026-06-12")
    assessment1 = db.Column(db.Integer, default=0)
    assessment2 = db.Column(db.Integer, default=0)
    exam = db.Column(db.Integer, default=0)
    final_mark = db.Column(db.Integer, default=0)
    grade = db.Column(db.String(10), default="Pending")
    status = db.Column(db.String(30), default="Enrolled")

    student = db.relationship("Student", backref=db.backref("subjects", lazy=True, cascade="all, delete-orphan"), foreign_keys=[student_username])

def clamp(value, minimum=0, maximum=100):
    return max(minimum, min(maximum, int(round(value))))

def grade_from_mark(mark):
    for minimum, grade in GRADE_BANDS:
        if mark >= minimum:
            return grade
    return "F"

def status_from_mark(mark):
    return "Completed" if mark >= 50 else "At Risk"

FEATURE_NAMES = ["attendance", "study_hours", "assignments", "quiz", "lms_logins", "engagement", "missed_tasks"]

def baseline_score(attendance, study_hours, assignments, quiz, lms_logins, engagement, missed_tasks):
    assignment_percent = (assignments / 5) * 100
    study_score = min(study_hours * 20, 100)
    lms_score = min(lms_logins * 10, 100)
    productivity = clamp((attendance * 0.25) + (study_score * 0.15) + (assignment_percent * 0.20) + (quiz * 0.20) + (lms_score * 0.10) + (engagement * 0.10) - (missed_tasks * 4))
    pass_probability = clamp(productivity + ((quiz - 50) * 0.20) - (missed_tasks * 2), 20, 98)
    if productivity < 60:
        risk = "High"
    elif productivity < 80:
        risk = "Medium"
    else:
        risk = "Low"
    expected_grade = grade_from_mark(productivity)
    return productivity, pass_probability, risk, expected_grade

def build_random_forest_models():
    rng = random.Random(42)
    rows, productivity_y, pass_y, risk_y, grade_y = [], [], [], [], []
    for _ in range(900):
        row = [rng.randint(40, 100), rng.randint(0, 6), rng.randint(0, 5), rng.randint(25, 100), rng.randint(0, 12), rng.randint(20, 100), rng.randint(0, 5)]
        productivity, pass_probability, risk, expected_grade = baseline_score(*row)
        rows.append(row); productivity_y.append(productivity); pass_y.append(pass_probability); risk_y.append(risk); grade_y.append(expected_grade)

    X_train, X_test, risk_train, risk_test = train_test_split(rows, risk_y, test_size=0.25, random_state=42, stratify=risk_y)
    _, _, grade_train, grade_test = train_test_split(rows, grade_y, test_size=0.25, random_state=42, stratify=grade_y)
    _, _, prod_train, prod_test = train_test_split(rows, productivity_y, test_size=0.25, random_state=42)
    _, _, pass_train, pass_test = train_test_split(rows, pass_y, test_size=0.25, random_state=42)

    risk_model = RandomForestClassifier(n_estimators=180, max_depth=8, random_state=42, class_weight="balanced")
    grade_model = RandomForestClassifier(n_estimators=180, max_depth=8, random_state=42, class_weight="balanced")
    productivity_model = RandomForestRegressor(n_estimators=180, max_depth=8, random_state=42)
    pass_model = RandomForestRegressor(n_estimators=180, max_depth=8, random_state=42)
    risk_model.fit(X_train, risk_train); grade_model.fit(X_train, grade_train); productivity_model.fit(X_train, prod_train); pass_model.fit(X_train, pass_train)

    evidence = {
        "risk_accuracy": round(accuracy_score(risk_test, risk_model.predict(X_test)) * 100, 1),
        "grade_accuracy": round(accuracy_score(grade_test, grade_model.predict(X_test)) * 100, 1),
        "productivity_mae": round(mean_absolute_error(prod_test, productivity_model.predict(X_test)), 2),
        "pass_mae": round(mean_absolute_error(pass_test, pass_model.predict(X_test)), 2),
        "training_rows": len(rows),
        "model_name": "Random Forest ML Engine",
    }
    return risk_model, grade_model, productivity_model, pass_model, evidence

RISK_MODEL, GRADE_MODEL, PRODUCTIVITY_MODEL, PASS_MODEL, MODEL_EVIDENCE = build_random_forest_models()

def explain_prediction(inputs, risk):
    attendance, study_hours, assignments, quiz, lms_logins, engagement, missed_tasks = inputs
    reasons = []
    if attendance < 75: reasons.append("Attendance is below the institutional target and increases risk.")
    if study_hours < 2: reasons.append("Study hours are low for independent BIT learning.")
    if assignments < 3: reasons.append("Assignment completion is below the expected progress level.")
    if quiz < 50: reasons.append("Quiz performance requires academic support.")
    if lms_logins < 4: reasons.append("LMS activity is low for weekly engagement.")
    if engagement < 60: reasons.append("Engagement score is below expectation.")
    if missed_tasks > 0: reasons.append(f"There are {missed_tasks} missed task(s) affecting risk.")
    top_features = sorted(zip(FEATURE_NAMES, RISK_MODEL.feature_importances_), key=lambda item: item[1], reverse=True)[:3]
    important = ", ".join([name.replace("_", " ") for name, _ in top_features])
    base = f"Random Forest considered the strongest indicators as {important}."
    return base + " " + (" ".join(reasons) if reasons else "The student is stable across key academic indicators.")

def calculate_prediction(attendance, study_hours, assignments, quiz, lms_logins, engagement, missed_tasks):
    inputs = [attendance, study_hours, assignments, quiz, lms_logins, engagement, missed_tasks]
    risk = RISK_MODEL.predict([inputs])[0]
    expected_grade = GRADE_MODEL.predict([inputs])[0]
    productivity = clamp(PRODUCTIVITY_MODEL.predict([inputs])[0])
    pass_probability = clamp(PASS_MODEL.predict([inputs])[0], 20, 98)
    if risk == "High":
        notification = "High Risk: meet the lecturer, complete pending work, and follow a weekly improvement plan."
        recommendation = "Complete one missed task, attend support consultation, and increase study hours this week."
        teacher_action = "Schedule a follow-up, check missing tasks, and create a short intervention plan."
    elif risk == "Medium":
        notification = "Medium Risk: consistency is required before the due period."
        recommendation = "Study at least 30 minutes daily, keep LMS activity consistent, and submit tasks before due dates."
        teacher_action = "Monitor weekly progress and send a supportive reminder."
    else:
        notification = "Low Risk: current performance is stable."
        recommendation = "Maintain study routine and attempt extension practice."
        teacher_action = "Give positive feedback and offer advanced tasks."
    return {"productivity": productivity, "pass_probability": pass_probability, "risk": risk, "expected_grade": expected_grade, "notification": notification, "recommendation": recommendation, "teacher_action": teacher_action, "reason": explain_prediction(inputs, risk)}

def apply_prediction(student):
    result = calculate_prediction(student.attendance, student.study_hours, student.assignments, student.quiz, student.lms_logins, student.engagement, student.missed_tasks)
    for key, value in result.items(): setattr(student, key, value)

def update_subject_results(student):
    subjects = SubjectEnrollment.query.filter_by(student_username=student.username).all()
    if not subjects: return
    for sub in subjects:
        if sub.final_mark == 0:
            predicted = clamp((student.productivity * 0.35) + (student.quiz * 0.35) + (student.attendance * 0.15) + (student.engagement * 0.15) - (student.missed_tasks * 2))
            sub.assessment1 = clamp(predicted - random.randint(0, 8))
            sub.assessment2 = clamp(predicted + random.randint(-6, 6))
            sub.exam = clamp(predicted + random.randint(-8, 8))
            sub.final_mark = clamp((sub.assessment1 * 0.30) + (sub.assessment2 * 0.30) + (sub.exam * 0.40))
        sub.grade = grade_from_mark(sub.final_mark)
        sub.status = status_from_mark(sub.final_mark)

def get_badges(student):
    badges = []
    if student.streak >= 5: badges.append("Consistent Learner")
    if student.assignments >= 4: badges.append("On-Time Submitter")
    if student.study_hours >= 4: badges.append("Focus Champion")
    if student.attendance >= 85: badges.append("Attendance Star")
    if student.quiz >= 75: badges.append("Quiz Improver")
    if student.risk == "Low": badges.append("Low Risk Performer")
    return badges or ["Starter Badge"]

def weekly_data(student):
    return {
        "labels": ["Week 1", "Week 2", "Week 3", "Week 4"],
        "attendance": [clamp(student.attendance - 10), clamp(student.attendance - 5), clamp(student.attendance - 2), student.attendance],
        "productivity": [clamp(student.productivity - 12), clamp(student.productivity - 6), clamp(student.productivity - 3), student.productivity],
        "engagement": [clamp(student.engagement - 12), clamp(student.engagement - 8), clamp(student.engagement - 4), student.engagement],
    }

def get_students_list(): return Student.query.order_by(Student.year_level, Student.name).all()

def summary_data():
    students = get_students_list()
    if not students:
        return {"students": [], "total_students": 0, "high_risk": 0, "medium_risk": 0, "low_risk": 0, "avg_attendance": 0, "avg_score": 0, "avg_pass": 0}
    return {"students": students, "total_students": len(students), "high_risk": len([s for s in students if s.risk == "High"]), "medium_risk": len([s for s in students if s.risk == "Medium"]), "low_risk": len([s for s in students if s.risk == "Low"]), "avg_attendance": round(sum(s.attendance for s in students) / len(students)), "avg_score": round(sum(s.productivity for s in students) / len(students)), "avg_pass": round(sum(s.pass_probability for s in students) / len(students))}

def default_subjects_for(student):
    choices = BIT_UNITS.get(student.year_level, BIT_UNITS[1])[:4]
    tri = TRIMESTERS[student.trimester]
    return [SubjectEnrollment(student_username=student.username, unit_code=c, unit_name=n, year_level=student.year_level, trimester=student.trimester, assessment_due=tri["assessment_due"], result_release=tri["results"]) for c,n in choices]

def seed_data():
    if User.query.first(): return
    users = [
        User(username="admin", password="123", role="admin", full_name="System Admin"),
        User(username="teacher", password="123", role="teacher", full_name="Academic Teacher"),
        User(username="laxman", password="123", role="student", full_name="Laxman Shrestha"),
        User(username="nabin", password="123", role="student", full_name="Nabin Balami"),
        User(username="nishan", password="123", role="student", full_name="Nishan Singtan Tamang"),
        User(username="aakriti", password="123", role="student", full_name="Aakriti Chhetri"),
        User(username="maya", password="123", role="student", full_name="Maya Gurung"),
        User(username="suman", password="123", role="student", full_name="Suman Rai"),
    ]
    db.session.add_all(users)
    students = [
        Student(username="laxman", name="Laxman Shrestha", student_id="S2400285", year_level=3, trimester="Trimester 1 2026", attendance=72, study_hours=2, assignments=3, quiz=62, lms_logins=5, engagement=60, missed_tasks=1, streak=4),
        Student(username="nabin", name="Nabin Balami", student_id="S2400517", year_level=3, trimester="Trimester 1 2026", attendance=80, study_hours=3, assignments=4, quiz=74, lms_logins=7, engagement=72, missed_tasks=1, streak=6),
        Student(username="nishan", name="Nishan Singtan Tamang", student_id="S2400294", year_level=3, trimester="Trimester 1 2026", attendance=91, study_hours=5, assignments=5, quiz=86, lms_logins=9, engagement=88, missed_tasks=0, streak=9),
        Student(username="aakriti", name="Aakriti Chhetri", student_id="S2500412", year_level=2, trimester="Trimester 2 2026", attendance=68, study_hours=2, assignments=2, quiz=58, lms_logins=4, engagement=55, missed_tasks=2, streak=3),
        Student(username="maya", name="Maya Gurung", student_id="S2600117", year_level=1, trimester="Trimester 3 2026", attendance=84, study_hours=3, assignments=4, quiz=78, lms_logins=8, engagement=80, missed_tasks=0, streak=7),
        Student(username="suman", name="Suman Rai", student_id="S2500332", year_level=2, trimester="Trimester 2 2026", attendance=58, study_hours=1, assignments=1, quiz=46, lms_logins=2, engagement=42, missed_tasks=4, streak=1),
    ]
    for student in students:
        apply_prediction(student); db.session.add(student); db.session.flush()
        for subject in default_subjects_for(student): db.session.add(subject)
    db.session.commit()
    for student in students: update_subject_results(student)
    db.session.commit()

@app.route("/")
def home(): return render_template("login.html")

@app.route("/login", methods=["POST"])
def login():
    username = request.form["username"].strip().lower(); password = request.form["password"].strip()
    user = User.query.filter_by(username=username, password=password).first()
    if not user: return render_template("login.html", error="Invalid login details. Try admin/123, teacher/123, or student username/123.")
    return redirect(url_for("admin" if user.role == "admin" else "teacher" if user.role == "teacher" else "student_profile", username=user.username) if user.role == "student" else url_for(user.role))

@app.route("/student/<username>")
def student_profile(username):
    student = Student.query.filter_by(username=username.lower()).first()
    if not student: return redirect(url_for("home"))
    return render_template("student.html", student=student, badges=get_badges(student), chart=weekly_data(student), subjects=student.subjects, trimesters=TRIMESTERS)

@app.route("/student/<username>/subjects", methods=["GET", "POST"])
def student_subjects(username):
    student = Student.query.filter_by(username=username.lower()).first()
    if not student: return redirect(url_for("home"))
    if request.method == "POST":
        student.year_level = int(request.form["year_level"]); student.trimester = request.form["trimester"]
        selected = request.form.getlist("subjects")[:4]
        SubjectEnrollment.query.filter_by(student_username=student.username).delete()
        tri = TRIMESTERS[student.trimester]
        valid_units = {code: name for code, name in BIT_UNITS[student.year_level]}
        for code in selected:
            if code in valid_units:
                db.session.add(SubjectEnrollment(student_username=student.username, unit_code=code, unit_name=valid_units[code], year_level=student.year_level, trimester=student.trimester, assessment_due=tri["assessment_due"], result_release=tri["results"]))
        db.session.commit(); update_subject_results(student); db.session.commit()
        return redirect(url_for("student_profile", username=student.username))
    return render_template("subjects.html", student=student, bit_units=BIT_UNITS, trimesters=TRIMESTERS)

@app.route("/predict", methods=["POST"])
def predict():
    student = Student.query.filter_by(username=request.form["username"].strip().lower()).first()
    if not student: return redirect(url_for("home"))
    for field in ["name", "student_id", "course"]: setattr(student, field, request.form[field].strip())
    student.year_level = int(request.form["year_level"]); student.trimester = request.form["trimester"]
    for field in ["attendance", "study_hours", "assignments", "quiz", "lms_logins", "engagement", "missed_tasks", "streak", "daily_goal_done", "weekly_goal_done"]: setattr(student, field, int(request.form[field]))
    apply_prediction(student); update_subject_results(student); db.session.commit()
    return redirect(url_for("student_profile", username=student.username))

@app.route("/teacher")
def teacher():
    data = summary_data(); chart = {"labels": [s.name for s in data["students"]], "attendance": [s.attendance for s in data["students"]], "productivity": [s.productivity for s in data["students"]], "engagement": [s.engagement for s in data["students"]]}
    return render_template("teacher.html", **data, chart=chart, trimesters=TRIMESTERS)

@app.route("/teacher/student/<username>")
def teacher_student_detail(username):
    student = Student.query.filter_by(username=username.lower()).first()
    if not student: return redirect(url_for("teacher"))
    return render_template("student_detail.html", student=student, badges=get_badges(student), chart=weekly_data(student), subjects=student.subjects, trimesters=TRIMESTERS)

@app.route("/admin")
def admin():
    data = summary_data(); teachers = User.query.filter_by(role="teacher").all()
    return render_template("admin.html", **data, teachers=teachers, bit_units=BIT_UNITS, trimesters=TRIMESTERS)

@app.route("/admin/add_student", methods=["POST"])
def admin_add_student():
    username = request.form["username"].strip().lower()
    if not username or User.query.filter_by(username=username).first(): return redirect(url_for("admin"))
    user = User(username=username, password=request.form.get("password", "123").strip() or "123", role="student", full_name=request.form["name"].strip())
    student = Student(username=username, name=request.form["name"].strip(), student_id=request.form["student_id"].strip(), course=request.form.get("course", "Bachelor of Information Technology"), teacher_name=request.form.get("teacher_name", "Academic Teacher"), year_level=int(request.form.get("year_level", 1)), trimester=request.form.get("trimester", "Trimester 1 2026"), attendance=int(request.form.get("attendance", 75)), study_hours=int(request.form.get("study_hours", 2)), assignments=int(request.form.get("assignments", 3)), quiz=int(request.form.get("quiz", 65)), lms_logins=int(request.form.get("lms_logins", 5)), engagement=int(request.form.get("engagement", 60)), missed_tasks=int(request.form.get("missed_tasks", 1)))
    apply_prediction(student); db.session.add(user); db.session.add(student); db.session.flush()
    for subject in default_subjects_for(student): db.session.add(subject)
    db.session.commit(); update_subject_results(student); db.session.commit()
    return redirect(url_for("admin"))

@app.route("/admin/edit_student/<username>", methods=["GET", "POST"])
def admin_edit_student(username):
    student = Student.query.filter_by(username=username.lower()).first()
    if not student: return redirect(url_for("admin"))
    if request.method == "POST":
        for field in ["name", "student_id", "course", "teacher_name"]: setattr(student, field, request.form[field].strip())
        student.year_level = int(request.form["year_level"]); student.trimester = request.form["trimester"]
        for field in ["attendance", "study_hours", "assignments", "quiz", "lms_logins", "engagement", "missed_tasks", "streak", "daily_goal_done", "weekly_goal_done"]: setattr(student, field, int(request.form[field]))
        apply_prediction(student); update_subject_results(student)
        user = User.query.filter_by(username=student.username).first()
        if user: user.full_name = student.name
        db.session.commit(); return redirect(url_for("admin"))
    return render_template("edit_student.html", student=student, trimesters=TRIMESTERS)

@app.route("/admin/delete_student/<username>", methods=["POST"])
def admin_delete_student(username):
    username = username.lower(); SubjectEnrollment.query.filter_by(student_username=username).delete()
    student = Student.query.filter_by(username=username).first(); user = User.query.filter_by(username=username, role="student").first()
    if student: db.session.delete(student)
    if user: db.session.delete(user)
    db.session.commit(); return redirect(url_for("admin"))

@app.route("/download_report/<username>")
def download_report(username):
    student = Student.query.filter_by(username=username.lower()).first()
    if not student: return redirect(url_for("teacher"))
    subjects = "\n".join([f"- {s.unit_code} {s.unit_name}: {s.final_mark}% ({s.grade}), Due {s.assessment_due}, Result {s.result_release}" for s in student.subjects])
    report = f"""AI-Based Student Productivity and Performance Prediction Report\n\nStudent: {student.name}\nID: {student.student_id}\nCourse: {student.course}\nYear Level: Year {student.year_level}\nTrimester: {student.trimester}\nTeacher: {student.teacher_name}\n\nSubjects and Results:\n{subjects}\n\nAttendance: {student.attendance}%\nStudy Hours: {student.study_hours}\nAssignments: {student.assignments}/5\nQuiz: {student.quiz}%\nLMS Logins: {student.lms_logins}\nEngagement: {student.engagement}%\nMissed Tasks: {student.missed_tasks}\n\nRandom Forest Output:\nProductivity: {student.productivity}%\nRisk: {student.risk}\nExpected Grade: {student.expected_grade}\nPass Probability: {student.pass_probability}%\n\nReason:\n{student.reason}\n\nStudent Recommendation:\n{student.recommendation}\n\nTeacher Action:\n{student.teacher_action}\n""".strip()
    return Response(report, mimetype="text/plain", headers={"Content-Disposition": f"attachment;filename={student.username}_academic_report.txt"})

@app.route("/download_class_report")
def download_class_report():
    output = StringIO(); writer = csv.writer(output)
    writer.writerow(["Name", "ID", "Year", "Trimester", "Subjects", "Attendance", "Productivity", "Risk", "Expected Grade", "Pass Probability", "Recommendation"])
    for s in get_students_list(): writer.writerow([s.name, s.student_id, s.year_level, s.trimester, len(s.subjects), f"{s.attendance}%", f"{s.productivity}%", s.risk, s.expected_grade, f"{s.pass_probability}%", s.recommendation])
    return Response(output.getvalue(), mimetype="text/csv", headers={"Content-Disposition": "attachment;filename=bit_class_performance_report.csv"})

@app.route("/model")
def model():
    importance = sorted(zip(FEATURE_NAMES, RISK_MODEL.feature_importances_), key=lambda item: item[1], reverse=True)
    return render_template("model.html", evidence=MODEL_EVIDENCE, importance=importance)

@app.route("/demo")
def demo():
    data = summary_data(); sample_student = Student.query.order_by(Student.productivity).first(); chart = {"labels": [s.name for s in data["students"]], "productivity": [s.productivity for s in data["students"]], "attendance": [s.attendance for s in data["students"]]}
    return render_template("demo.html", **data, student=sample_student, chart=chart, evidence=MODEL_EVIDENCE, subjects=sample_student.subjects if sample_student else [])

@app.route("/tutorial")
def tutorial(): return render_template("tutorial.html", trimesters=TRIMESTERS, bit_units=BIT_UNITS)
@app.route("/privacy")
def privacy(): return render_template("privacy.html")
@app.route("/logout")
def logout(): return redirect(url_for("home"))

with app.app_context():
    db.create_all(); seed_data()

if __name__ == "__main__":
    app.run(debug=True)
